#!/usr/bin/env bash

gut "Just built"
cp ./.package.dev.json ./package.json
cp ./src/.common.dev.js ./src/common.js

