#!/usr/bin/env bash

cp ./.package.build.json ./package.json
cp ./src/.common.build.js ./src/common.js

